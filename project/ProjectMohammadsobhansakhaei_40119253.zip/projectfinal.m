clc;
clear all;
close all;
%% question 1
data=load('Data.mat');
magnitude=data.Data.magnitude;
phase=data.Data.phase;
w=data.Data.omega;
subplot(2,1,1);
semilogx(w,20*log10(magnitude));
xlabel('Frequency (Hz)');
ylabel('Magnitude (dB)');
title(' Magnitude');
grid on;
subplot(2,1,2);
semilogx(w,phase);
xlabel('Frequency (Hz)');
ylabel('Phase (deg)');
title('Phase');
grid on;
%% question 3
% question 3_1
p_rad=deg2rad(phase);
L=magnitude.*exp(1j*p_rad);
Ts=0;
data_w=idfrd(L,w,Ts);
z=1;
p=3;
sys_tf=tfest(data_w,p,z);
fprintf("The properties of this model and the transform function of the system:");
sys_tf
figure;
bode(sys_tf);
xlim([10e-4,10e3]);
grid;
%% question 5
% 5-1
figure;
rlocus(sys_tf);
grid;
hold on;
rlocus(-sys_tf,'-.');
% 5-2
s=tf('s');
t=0:0.001:40;
c=-9.8049*(s+0.1112)/s;
g=(0.1*s-0.2)/(s^3+0.9*s^2+9*s);
l=c*g;
T=l/(1+l);
figure;
step(T,t);
grid;
fprintf("The properties of the system with pI controller.The system become stable");
stepinfo(T)
%% question 6
t=0:0.001:10;
G_new=0.1/(s^2+0.9*s+9);
figure;
bode(G_new);
margin(G_new);
grid;
figure;
T_new=G_new/(1+G_new);
step(T_new,t);
grid;
fprintf("\nThe output of the system with out any controller");
stepinfo(T_new)
c_2=97380*((9+s)*(10+s))/((110+s)*(100+s));
l2=c_2*G_new;
figure;
bode(l2);
margin(l2);
grid;
T_c=(l2)/(1+l2);
figure;
step(T_c,t);
grid;
fprintf("\nThe output of the system with controller");
stepinfo(T_c)
%
c=(53.696*((1.94*s+1)*(0.349*s+1)))/((3.10*s+1)*(0.246*s+1));
l3=c*G_new;
figure;
bode(l3);
margin(l3);
grid;
T6=l3/(1+l3);
figure;
step(T6,t);
grid;
%% question 7
% question 7-1
t=0:0.01:50;
s=tf('s');
sys=(0.1*(s-2))/(s^3+0.9*s^2+9*s);
c=(-21.241*(s+0.001)*(s+1))/s^2;
l=(c)*sys;
figure;
bode(l);
grid;
margin(l);
g=1/s;
T=l/(s*(1+l));
figure;
step(T,t);
grid;
% question 7-2
s=tf('s');
sys=(0.1*(s-2))/(s^3+0.9*s^2+9*s);
c=(-5.75*(s^3+0.9*s^2+9*s))/(s^3+3*s^2+3.5*s);
l=c*sys;
h=l/(1+l);
figure;
step(h,t);
grid;
fprintf("\nDesigning the controller with sensivity function:");
stepinfo(h)