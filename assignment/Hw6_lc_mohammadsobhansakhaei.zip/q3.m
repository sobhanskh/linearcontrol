clc;
clear all;
close all;
%%
t=0:0.1:10;
s=tf('s');
g=exp(-0.4*s)/(s*(0.2*s+1));
c=(0.048*s+1);
l=c*g;
figure;
bode(g);
margin(g);
grid;
figure;
bode(l);
margin(l);
grid;
T=l/(l+1);
T=step(T,t);
stepinfo(T,t)
figure;
plot(t,T);
grid;