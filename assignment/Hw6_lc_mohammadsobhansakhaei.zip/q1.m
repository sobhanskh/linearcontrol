clc;
clear all;
close all;
%%
t=0:0.01:10;
num=10;
den=[1,5,11,15,0];
sys=tf(num,den);
figure;
bode(sys);
margin(sys);
grid;
num1=[8379,300];
den1=[838.15,4191.75,9224.65,12583.25,15,0];
figure;
sys1=tf(num1,den1);
bode(sys1);
margin(sys1);
grid;
