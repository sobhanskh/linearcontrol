clc;
clear all;
close all;
%%
t=0:0.1:2;
s=tf('s');
g=2500/(s*(s+25));
c1=0.74*((0.0273*s+1)/(0.015*s+1));
c2=1.34*((0.106*s+1)/(0.143*s+1));
c=c1*c2;
l=c*g;
figure;
bode(g);
margin(g);
grid;
figure;
bode(l);
margin(l);
grid;
T=l/(l+1);
b=step(T,t);
stepinfo(b)
figure;
plot(t,b);
grid;
