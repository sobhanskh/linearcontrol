clc;
clear all;
close all;
%%
t=0:0.001:5;
sys=tf([5 10],[1 4 5]);
z=roots([5 10]);
p=roots([1 4 5]);
fprintf("poles:\n");
disp(p);
fprintf("\nzeroes:\n");
disp(z);
y=step(sys,t);
info=stepinfo(y,t);
figure;
plot(t,y,"Color",'red');
title("step response");
xlabel("time(s)");
ylabel("step response");
grid on;
text(info.RiseTime,info.RiseTime,sprintf('Rise Time:%.2f s',info.RiseTime),"Color",'red');
text(info.Overshoot,max(y)*0.9,sprintf('overshoot:%.2f%%',info.Overshoot),"Color",'magenta');
text(info.Peak,info.Peak,sprintf('peak:%.2f',info.Peak),"Color",'blue');
disp(info);
% خطای حالت ماندگار آن برابر با یک می باشد چرا که پاسخ حالت ماندگار سیستم
% به ورودی پله برابر با دو شده است در حالیکه باید ورودی را که وضعیت مطلوب
% ماست و برابر با یک است دنبال می کرد بنابراین خطای حالت ماندگار برابر با
% یک خواهد شد.
