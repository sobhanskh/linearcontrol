clc;
clear all;
close all;
%%
num=-1;
den=[-1 1 0];
sys=tf(num,den);
nyquist(sys);
grid
set(findall(figure(1),'type','line'),'linewidth',2);
