clc;
clear all;
close all;
%%
tau=2;
s=tf('s');
sys1=(5.*(s+1))/(s.*((5.*s)+1));
sys=sys1.*exp(-tau.*s);
bode(sys);
grid;
set(findall(figure(1),'type','line'),'linewidth',2);