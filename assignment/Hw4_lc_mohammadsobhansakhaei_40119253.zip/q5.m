clc;
clear all;
close all;
%%
num=[0.01 0.1];
den=[0.01 1];
sys=tf(num,den);
nyquist(sys);
grid;
set(findall(figure(1),'type','line'),'linewidth',2);