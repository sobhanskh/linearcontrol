clc;
clear all;
close all;
%%
s=tf('s');
z=[-1 -2 -3 -4];
k=-1;
p=[0 0 0 -100];
sys=zpk(z,p,k);
bode(sys);
grid;
set(findall(figure(1),'type','line'),'linewidth',2);
figure(2);
nyquist(sys);
grid;
set(findall(figure(2),'type','line'),'linewidth',2);