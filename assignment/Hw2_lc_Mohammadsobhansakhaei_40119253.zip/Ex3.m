clc;
clear all;
close all;
%%
t=0:0.0001:5;
num=8.3874;
den=[1 4 8.3874];
sys=tf(num,den);
y=step(sys,t);
figure;
plot(t,y,"Color",'green','LineWidth',1.5);
xlabel("Time(seconds)");
ylabel("Amplitude","FontSize",12);
title("step response for 5% overshoot");
grid on;