clc;
clear all;
close all;
%%
t=0:0.01:2.5;
omegan = 11.1499;
omega2=omegan^2;
zeta = 0.2509;
k=1.58;
num1=k*omega2;
den1=[1 2*omegan*zeta omega2];
T_s=tf(num1,den1);
T_t=step(T_s,t);
num2=k*omega2;
den2=[1 2*zeta*omegan (1-k)*omega2];
L_s=tf(num2,den2);
L_t=step(L_s,t);
figure;
plot(t,T_t,"Color",'red','LineWidth',1.5);
ylabel("Amplitude","FontSize",12);
xlabel("Time(seconds)","FontSize",12);
title("step response for close loop","FontSize",14);
grid on;
figure;
plot(t,L_t,"Color",'blue','LineWidth',1.5);
ylabel("Amplitude","FontSize",12);
xlabel("Time(seconds)","FontSize",12);
title("step response for open loop","FontSize",14);
grid on;


