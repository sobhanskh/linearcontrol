clc;
clear all;
close all;
%%
t=0:0.0001:10;
num1=0.4;
den1=[1 0.8];
sys1=tf(num1,den1);
y1=step(sys1,t);
figure;
plot(t,y1,"Color",'cyan','LineWidth',1.5);
grid on;
xlabel("Time(seconds)","FontSize",12);
ylabel("Amplitude",'FontSize',12);
title("step response for close loop system");
num2=0.4;
den2=[1 0.4];
sys2=tf(num2,den2);
y2=step(sys2,t);
figure;
plot(t,y2,"Color",'blue','LineWidth',1.5);
grid on;
xlabel("Time(seconds)","FontSize",12);
ylabel("Amplitude","FontSize",12);
title("step response for open loop system");

