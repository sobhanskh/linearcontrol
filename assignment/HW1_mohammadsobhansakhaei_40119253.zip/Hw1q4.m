clc;
clear;
close all;
%% T2=Y5/Y1
s=zpk('s');
G1=1/s;
G2=2*s+1;
G3=1/(s^2+1);
G4=s/(s+1);
H1=3/s;
H2=(s-1)/(s+3);
H3=s/(s^2+3*s+1);
H4=1/(s+2);
systemnames='G1 G2 G3 G4 H1 H2 H3 H4';
inputvar='[r]';
outputvar='[G3 - H4]';
input_to_G1='[r -H3 -H1]';
input_to_G2='[G1]';
input_to_G3='[G2 +G4 - H2]';
input_to_G4='[r -H3 -H1]';
input_to_H1='[G1]';
input_to_H2='[G3 - H4]';
input_to_H3='[G3 - H4]';
input_to_H4='[G3 - H4]';
sysoutname='plant_ic';
cleanupsysic='yes';
sysic
plant_ic.Inputname={'Y1'};
plant_ic.outputname={'Y5'};
T2=minreal(plant_ic);
T2
fprintf("the poles of the Y5/Y1:\n");
x=pole(T2);
disp(x);

%% T1=Y5/Y2
s=zpk('s');
G1=1/s;
G2=2*s+1;
G3=1/(s^2+1);
G4=s/(s+1);
H1=3/s;
H2=(s-1)/(s+3);
H3=s/(s^2+3*s+1);
H4=1/(s+2);
systemnames='G1 G2 G3 G4 H1 H2 H3 H4';
inputvar='[r]';
outputvar='[r -H3 -H1]';
input_to_G1='[r -H3 -H1]';
input_to_G2='[G1]';
input_to_G3='[G2 +G4 - H2]';
input_to_G4='[r -H3 -H1]';
input_to_H1='[G1]';
input_to_H2='[G3 - H4]';
input_to_H3='[G3 - H4]';
input_to_H4='[G3 - H4]';
sysoutname='plant_ic1';
cleanupsysic='yes';
sysic
plant_ic1.Inputname={'Y1'};
plant_ic1.outputname={'Y2'};
plant_ic1=minreal(plant_ic1);
T1=minreal(T2/plant_ic1);
T1



